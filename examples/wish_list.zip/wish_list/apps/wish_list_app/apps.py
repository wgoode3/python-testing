# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class WishListAppConfig(AppConfig):
    name = 'wish_list_app'
