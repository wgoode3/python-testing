# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Wish

def index(req):
    return render(req, 'wish_list_app/index.html')

def register(req):
    user = User.userManager.register(req.POST)
    if user["logged_in"]:
        req.session["user"] = {
            "id": user["user"].id,
            "name": user["user"].name
        }
        return redirect('/dashboard')
    else:
        for error in user["errors"]:
            messages.add_message(req, messages.ERROR, error)
        return redirect('/')

def login(req):
    user = User.userManager.login(req.POST)
    if user["logged_in"]:
        req.session["user"] = {
            "id": user["user"].id,
            "name": user["user"].name
        }
        return redirect('/dashboard')
    else:
        for error in user["errors"]:
            messages.add_message(req, messages.ERROR, error)
        return redirect('/')

def logout(req):
    req.session.clear()
    return redirect('/')

def dashboard(req):
    if "user" not in req.session:
        messages.add_message(req, messages.ERROR, "You must login first!")
        return redirect("/")
    user_wishes = User.userManager.get(id=req.session["user"]["id"]).wish_list.all()
    other_wishes = Wish.wishManager.all()
    for wish in user_wishes:
        other_wishes = other_wishes.exclude(id=wish.id)
    return render(req, 'wish_list_app/dashboard.html', {"your_wishes":user_wishes, "other_wishes": other_wishes})

def new(req):
    if "user" not in req.session:
        messages.add_message(req, messages.ERROR, "You must login first!")
        return redirect("/")
    return render(req, 'wish_list_app/new_wish.html')

def create(req):
    wish = Wish.wishManager.makeWish(req.POST["product"], req.session["user"]["id"])
    if wish[0]:
        return redirect('/dashboard')
    else:
        messages.add_message(req, messages.ERROR, wish[1])
        return redirect('/wish_items/create')

def wish(req, id):
    if "user" not in req.session:
        messages.add_message(req, messages.ERROR, "You must login first!")
        return redirect("/")
    return render(req, 'wish_list_app/wish_item.html', {"wish": Wish.wishManager.get(id=id)})

def add(req, id):
    Wish.wishManager.addWish(id, req.session["user"]["id"])
    return redirect('/dashboard')

def remove(req, id):
    Wish.wishManager.removeWish(id, req.session["user"]["id"])
    return redirect('/dashboard')

def delete(req, id):
    Wish.wishManager.get(id=id).delete()
    return redirect('/dashboard')