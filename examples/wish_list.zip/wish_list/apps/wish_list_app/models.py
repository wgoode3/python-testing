# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from datetime import datetime
import bcrypt
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
	def register(self, data):
		response = {
			"user": None,
			"logged_in": False,
			"errors": []
		}

		if len(data["name"]) < 3:
			response["errors"].append("Name must be 3 characters or longer!")
		
		if len(data["alias"]) < 3:
			response["errors"].append("Alias must be 3 characters or longer!")
		
		if len(data["email"]) == 0:
			response["errors"].append("Email is required!")
		elif not EMAIL_REGEX.match(data["email"]):
			response["errors"].append("Invalid Email!")
		elif len(User.userManager.filter(email=data["email"])) > 0:
			response["errors"].append("Email already in use!")
			
		if len(data["password"]) < 8:
			response["errors"].append("Password must be 8 characters or longer!")

		if data["password"] != data["confirm_password"]:
			response["errors"].append("Confirm Password must match Password!")
		
		if len(data["date_of_birth"]) == 0:
			response["errors"].append("Date of Birth is required!")
		else:
			dob = datetime.strptime(data["date_of_birth"], '%Y-%m-%d')
			if dob > datetime.now():
				response["errors"].append("Date of Birth must be in the past!")

		if len(response["errors"]) == 0:
			response["logged_in"] = True
			response["user"] = User.userManager.create(
				name=data["name"],
				alias=data["alias"],
				email=data["email"],
				password=bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt()),
				date_of_birth=dob
			)
		return response

	def login(self, data):
		response = {
			"user": None,
			"logged_in": False,
			"errors": []
		}
		
		if len(data["email"]) == 0:
			response["errors"].append("Email is required!")
		elif not EMAIL_REGEX.match(data["email"]):
			response["errors"].append("Invalid email!")
			
		if len(data["password"]) < 8:
			response["errors"].append("Password must be 8 characters or longer!")

		if len(response["errors"]) == 0:
			user = User.userManager.filter(email=data["email"])
			if len(user) > 0:
				if bcrypt.checkpw(data["password"].encode(), user[0].password.encode()):
					response["logged_in"] = True
					response["user"] = user[0]
				else:
					response["errors"].append("Incorrect Password!")
			else:
				response["errors"].append("Email not found!")
		return response

class User(models.Model):
	name = models.CharField(max_length=255)
	alias = models.CharField(max_length=255)
	email = models.CharField(max_length=255)
	password = models.CharField(max_length=255)
	date_of_birth = models.DateField(max_length=255)

	userManager = UserManager()

class WishManager(models.Manager):
	def makeWish(self, product, creator):
		if len(product) < 1:
			return False, "Product is required!"
		elif len(product) < 3:
			return False, "Product must be 3 characters or more!"
		else:
			wish = Wish.wishManager.create(product=product, creator_id=creator)
			wish.wishers.add(User.userManager.get(id=creator))
			wish.save()
			return True, wish 

	def addWish(self, product, wisher):
		wish = Wish.wishManager.get(id=product)
		wish.wishers.add(User.userManager.get(id=wisher))
		wish.save()

	def removeWish(self, product, wisher):
		wish = Wish.wishManager.get(id=product)
		wish.wishers.remove(User.userManager.get(id=wisher))
		wish.save()

class Wish(models.Model):
	product = models.CharField(max_length=255)
	creator = models.ForeignKey(User, related_name="wishes")
	wishers = models.ManyToManyField(User, related_name="wish_list")
	created_at = models.DateTimeField(auto_now_add=True)

	wishManager = WishManager()\