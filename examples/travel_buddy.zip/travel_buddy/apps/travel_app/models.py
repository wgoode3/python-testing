# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from datetime import datetime
import bcrypt

class UserManager(models.Manager):
	def register(self, data):
		
		response = {
			"user": None,
			"logged_in": False,
			"errors": []
		}

		if len(data["name"]) < 3:
			response["errors"].append("Name must be 3 characters or longer!")
		
		if len(data["username"]) < 3:
			response["errors"].append("Username must be 3 characters or longer!")
		elif len(User.userManager.filter(username=data["username"])) > 0:
			response["errors"].append("Username already in use!")
			
		if len(data["password"]) < 8:
			response["errors"].append("Password must be 8 characters or longer!")

		if data["password"] != data["confirm_password"]:
			response["errors"].append("Confirm Password must match Password!")

		if len(response["errors"]) == 0:
			response["logged_in"] = True
			response["user"] = User.userManager.create(
				name=data["name"],
				username=data["username"],
				password=bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt())
			)
		return response

	def login(self, data):

		response = {
			"user": None,
			"logged_in": False,
			"errors": []
		}
		
		if len(data["username"]) < 3:
			response["errors"].append("Username must be 3 characters or longer!")
			
		if len(data["password"]) < 8:
			response["errors"].append("Password must be 8 characters or longer!")

		if len(response["errors"]) == 0:
			user = User.userManager.filter(username=data["username"])
			if len(user) > 0:
				if bcrypt.checkpw(data["password"].encode(), user[0].password.encode()):
					response["logged_in"] = True
					response["user"] = user[0]
				else:
					response["errors"].append("Incorrect Password!")
			else:
				response["errors"].append("Username not found!")
		return response

class User(models.Model):
	name = models.CharField(max_length=255)
	username = models.CharField(max_length=255)
	password = models.CharField(max_length=255)

	userManager = UserManager()

class TripManager(models.Manager):
	def addTrip(self, data, id):

		errors = []

		if len(data["destination"]) < 1:
			errors.append("Destination is required!")

		if len(data["description"]) < 1:
			errors.append("Description is required!")

		if len(data["start_date"]) < 1:
			errors.append("Start Date is required!")
			start = datetime.now() # assume now so we can run further tests
		else:
			start = datetime.strptime(data["start_date"], "%Y-%m-%d")
			if datetime.now() > start:
				errors.append("Start Date must be in the future!")

		if len(data["end_date"]) < 1:
			errors.append("End Date is required!")
		else:
			end = datetime.strptime(data["end_date"], "%Y-%m-%d")
			if end < datetime.now():
				errors.append("End Date must be in the future!")
			elif start > end:
				errors.append("End Date must be after Start Date!")

		if len(errors) > 0:
			return False, errors
		else:
			trip = Trip.tripManager.create(
				destination=data["destination"],
				description=data["description"],
				start_date=start,
				end_date=end,
				planner_id=id
			)
			return True, trip

class Trip(models.Model):
	destination = models.CharField(max_length=255)
	description = models.CharField(max_length=255)
	start_date = models.DateField()
	end_date = models.DateField()
	planner = models.ForeignKey(User, related_name="planned")
	attendees = models.ManyToManyField(User, related_name="attending")

	tripManager = TripManager()