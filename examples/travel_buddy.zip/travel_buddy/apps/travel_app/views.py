# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Trip

def index(req):
	return render(req, "travel_app/index.html")

def register(req):
	user = User.userManager.register(req.POST)
	if user["logged_in"]:
		req.session["user"] = {
			"id": user["user"].id,
			"name": user["user"].name
		}
		return redirect('/travels')
	else:
		for error in user["errors"]:
			messages.add_message(req, messages.ERROR, error)
		return redirect('/')

def login(req):
	user = User.userManager.login(req.POST)
	if user["logged_in"]:
		req.session["user"] = {
			"id": user["user"].id,
			"name": user["user"].name
		}
		return redirect('/travels')
	else:
		for error in user["errors"]:
			messages.add_message(req, messages.ERROR, error)
		return redirect('/')

def logout(req):
	req.session.clear()
	return redirect('/')

def travels(req):

	all_trips = Trip.tripManager.all()
	joined_trips = User.userManager.get(id=req.session["user"]["id"]).attending.all()

	for trip in joined_trips:
		all_trips = all_trips.exclude(id=trip.id)

	return render(req, "travel_app/travels.html", {"all_trips": all_trips, "joined_trips": joined_trips})

def new_trip(req):
	return render(req, "travel_app/new_trip.html")

def add_trip(req):
	trip = Trip.tripManager.addTrip(req.POST, req.session["user"]["id"])
	if trip[0]:
		trip[1].attendees.add(User.userManager.get(id=req.session["user"]["id"]))
		return redirect('/travels')
	else:
		for error in trip[1]:
			messages.add_message(req, messages.ERROR, error)
		return redirect("travels/add")

def join_trip(req, id):
	Trip.tripManager.get(id=id).attendees.add(User.userManager.get(id=req.session["user"]["id"]))
	return redirect("/travels")

def destination(req, id):
	return render(req, "travel_app/destination.html", {"trip": Trip.tripManager.get(id=id)})