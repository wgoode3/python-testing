# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from datetime import datetime
import bcrypt
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
	def register(self, data):
		
		response = {
			"user": None,
			"logged_in": False,
			"errors": []
		}

		if len(data["name"]) < 3:
			response["errors"].append("Name must be 3 characters or longer!")
		
		if len(data["alias"]) < 3:
			response["errors"].append("Alias must be 3 characters or longer!")
		
		if len(data["email"]) == 0:
			response["errors"].append("Email is required!")
		elif not EMAIL_REGEX.match(data["email"]):
			response["errors"].append("Invalid Email!")
		elif len(User.userManager.filter(email=data["email"])) > 0:
			response["errors"].append("Email already in use!")
			
		if len(data["password"]) < 8:
			response["errors"].append("Password must be 8 characters or longer!")

		if data["password"] != data["confirm_password"]:
			response["errors"].append("Confirm Password must match Password!")
		
		if len(data["date_of_birth"]) == 0:
			response["errors"].append("Date of Birth is required!")
		else:
			dob = datetime.strptime(data["date_of_birth"], '%Y-%m-%d')
			if dob > datetime.now():
				response["errors"].append("Date of Birth must be in the past!")

		if len(response["errors"]) == 0:
			response["logged_in"] = True
			response["user"] = User.userManager.create(
				name=data["name"],
				alias=data["alias"],
				email=data["email"],
				password=bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt()),
				date_of_birth=dob
			)
		return response

	def login(self, data):

		response = {
			"user": None,
			"logged_in": False,
			"errors": []
		}
		
		if len(data["email"]) == 0:
			response["errors"].append("Email is required!")
		elif not EMAIL_REGEX.match(data["email"]):
			response["errors"].append("Invalid email!")
			
		if len(data["password"]) < 8:
			response["errors"].append("Password must be 8 characters or longer!")

		if len(response["errors"]) == 0:
			user = User.userManager.filter(email=data["email"])
			if len(user) > 0:
				if bcrypt.checkpw(data["password"].encode(), user[0].password.encode()):
					response["logged_in"] = True
					response["user"] = user[0]
				else:
					response["errors"].append("Incorrect Password!")
			else:
				response["errors"].append("Email not found!")
		return response

class User(models.Model):
	name = models.CharField(max_length=255)
	alias = models.CharField(max_length=255)
	email = models.CharField(max_length=255)
	password = models.CharField(max_length=255)
	date_of_birth = models.DateField(max_length=255)

	userManager = UserManager()

class TaskManager(models.Manager):
	
	def addTask(self, data, user_id):

		response = {
			"saved": False,
			"errors": [],
			"task": None
		}

		if len(data["date"]) < 1:
			response["errors"].append("Date is required!")

		if len(data["time"]) < 1:
			response["errors"].append("Time is required!")

		if len(data["task"]) < 1:
			response["errors"].append("Task is required!")

		if len(response["errors"]) == 0:
			
			when = datetime.strptime("{} {}".format(data["date"], data["time"]) , "%Y-%m-%d %H:%M")

			if datetime.now().date() > when.date():
				response["errors"].append("Date must be in the future!")

			if len(Task.taskManager.filter(user_id=user_id).filter(when=when)) > 0:
				response["errors"].append("Appointment with this date and time already exists!")					

		if len(response["errors"]) == 0:
			response["saved"] = True
			response["task"] = Task.taskManager.create(
				when=when, 
				task=data["task"], 
				status="pending", 
				user_id=user_id
			)

		return response
	
	def updateTask(self, data, user_id, appointment_id):

		response = {
			"saved": False,
			"errors": [],
			"task": None
		}

		if len(data["date"]) < 1:
			response["errors"].append("Date is required!")

		if len(data["time"]) < 1:
			response["errors"].append("Time is required!")

		if len(data["task"]) < 1:
			response["errors"].append("Task is required!")

		if len(response["errors"]) == 0:
			
			when = datetime.strptime("{} {}".format(data["date"], data["time"]) , "%Y-%m-%d %H:%M")

			if datetime.now().date() > when.date():
				response["errors"].append("Date must be in the future!")

			appointments = Task.taskManager.filter(user_id=user_id).filter(when=when)
			appointments = appointments.exclude(id=appointment_id)

			if len(appointments) > 0:
				response["errors"].append("Appointment with this date and time already exists!")					

		if len(response["errors"]) == 0:
			response["saved"] = True
			task = Task.taskManager.get(id=appointment_id)
			task.task = data["task"]
			task.when = when
			task.status = data["status"]
			task.save()
			response["task"] = task

		return response

class Task(models.Model):
	when = models.DateTimeField()
	task = models.CharField(max_length=255)
	status = models.CharField(max_length=255)
	user = models.ForeignKey(User, related_name="tasks")

	taskManager = TaskManager()