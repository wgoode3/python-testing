# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect
from models import User, Task
from django.contrib import messages
from datetime import datetime

def index(req):
    return render(req, "appointments_app/index.html")

def register(req):
    user = User.userManager.register(req.POST)
    if user["logged_in"]:
        req.session["user"] = {
            "id": user["user"].id,
            "name": user["user"].name
        }
        return redirect('/appointments')
    else:
        for error in user["errors"]:
            messages.add_message(req, messages.ERROR, error)
        return redirect('/')

def login(req):
    user = User.userManager.login(req.POST)
    if user["logged_in"]:
        req.session["user"] = {
            "id": user["user"].id,
            "name": user["user"].name
        }
        return redirect('/appointments')
    else:
        for error in user["errors"]:
            messages.add_message(req, messages.ERROR, error)
        return redirect('/')

def logout(req):
    req.session.clear()
    return redirect('/')

def appointments(req):

    if "user" not in req.session:
        messages.add_message(req, messages.ERROR, "You must login first!")
        return redirect("/")

    appointments = Task.taskManager.filter(user_id=req.session["user"]["id"]).order_by("when")

    context = {
        "todays_appointments": [a for a in appointments if a.when.date() == datetime.now().date()],
        "other_appointments": [a for a in appointments if a.when.date() > datetime.now().date()]
    }

    return render(req, "appointments_app/appointments.html", context)

def add(req):
    task = Task.taskManager.addTask(req.POST, req.session["user"]["id"])
    if not task["saved"]:
        for error in task["errors"]:
            messages.add_message(req, messages.ERROR, error)
    return redirect("/appointments")

def edit(req, id):

    if "user" not in req.session:
        messages.add_message(req, messages.ERROR, "You must login first!")
        return redirect("/")

    return render(req, "appointments_app/edit.html", {"appointment":Task.taskManager.get(id=id)})

def update(req, id):
    task = Task.taskManager.updateTask(req.POST, req.session["user"]["id"], id)
    if not task["saved"]:
        for error in task["errors"]:
            messages.add_message(req, messages.ERROR, error)
        return redirect("/appointments/{}".format(id))
    return redirect("/appointments")

def delete(req, id):
    Task.taskManager.get(id=id).delete()
    return redirect("/appointments")