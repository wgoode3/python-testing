# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User

def index(req):
	return render(req, "friends_app/index.html")

def register(req):
	user = User.userManager.register(req.POST)
	if user["logged_in"]:
		req.session["user"] = {
			"id": user["user"].id,
			"name": user["user"].name
		}
		return redirect('/friends')
	else:
		for error in user["errors"]:
			messages.add_message(req, messages.ERROR, error)
		return redirect('/')

def login(req):
	user = User.userManager.login(req.POST)
	if user["logged_in"]:
		req.session["user"] = {
			"id": user["user"].id,
			"name": user["user"].name
		}
		return redirect('/friends')
	else:
		for error in user["errors"]:
			messages.add_message(req, messages.ERROR, error)
		return redirect('/')

def logout(req):
	req.session.clear()
	return redirect('/')

def friends(req):
	if 'user' not in req.session:
		messages.add_message(req, messages.ERROR, "You must log in first!")

	friends = User.userManager.get(id=req.session["user"]["id"]).friends.all()
	users = User.userManager.all().exclude(id=req.session["user"]["id"])

	for user in friends:
		users = users.exclude(id=user.id)

	context = {
		"users": users,
		"friends": friends
	}
	return render(req, "friends_app/friends.html", context)

def showUser(req, id):
	user = User.userManager.get(id=id)
	return render(req, "friends_app/user.html", {"user": user})	

def addFriend(req, id):
	user = User.userManager.get(id=req.session["user"]["id"])
	friend = User.userManager.get(id=id)
	user.friends.add(friend)
	friend.friends.add(user)
	return redirect('/friends')

def removeFriend(req, id):
	user = User.userManager.get(id=req.session["user"]["id"])
	friend = User.userManager.get(id=id)
	user.friends.remove(friend)
	friend.friends.remove(user)
	return redirect('/friends')