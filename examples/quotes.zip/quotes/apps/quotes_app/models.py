# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from datetime import datetime
import bcrypt
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
	def register(self, data):
		
		response = {
			"user": None,
			"logged_in": False,
			"errors": []
		}

		if len(data["name"]) < 3:
			response["errors"].append("Name must be 3 characters or longer!")
		
		if len(data["alias"]) < 3:
			response["errors"].append("Alias must be 3 characters or longer!")
		
		if len(data["email"]) == 0:
			response["errors"].append("Email is required!")
		elif not EMAIL_REGEX.match(data["email"]):
			response["errors"].append("Invalid Email!")
		elif len(User.userManager.filter(email=data["email"])) > 0:
			response["errors"].append("Email already in use!")
			
		if len(data["password"]) < 8:
			response["errors"].append("Password must be 8 characters or longer!")

		if data["password"] != data["confirm_password"]:
			response["errors"].append("Confirm Password must match Password!")
		
		if len(data["date_of_birth"]) == 0:
			response["errors"].append("Date of Birth is required!")
		else:
			dob = datetime.strptime(data["date_of_birth"], '%Y-%m-%d')
			if dob > datetime.now():
				response["errors"].append("Date of Birth must be in the past!")

		if len(response["errors"]) == 0:
			response["logged_in"] = True
			response["user"] = User.userManager.create(
				name=data["name"],
				alias=data["alias"],
				email=data["email"],
				password=bcrypt.hashpw(data["password"].encode(), bcrypt.gensalt()),
				date_of_birth=dob
			)
		return response

	def login(self, data):

		response = {
			"user": None,
			"logged_in": False,
			"errors": []
		}
		
		if len(data["email"]) == 0:
			response["errors"].append("Email is required!")
		elif not EMAIL_REGEX.match(data["email"]):
			response["errors"].append("Invalid email!")
			
		if len(data["password"]) < 8:
			response["errors"].append("Password must be 8 characters or longer!")

		if len(response["errors"]) == 0:
			user = User.userManager.filter(email=data["email"])
			if len(user) > 0:
				if bcrypt.checkpw(data["password"].encode(), user[0].password.encode()):
					response["logged_in"] = True
					response["user"] = user[0]
				else:
					response["errors"].append("Incorrect Password!")
			else:
				response["errors"].append("Email not found!")
		return response

class User(models.Model):
	name = models.CharField(max_length=255)
	alias = models.CharField(max_length=255)
	email = models.CharField(max_length=255)
	password = models.CharField(max_length=255)
	date_of_birth = models.DateField(max_length=255)

	userManager = UserManager()

class QuoteManager(models.Manager):
	def addQuote(self, data, id):
		
		errors = []

		if len(data["quoted_by"]) < 3:
			errors.append("Quoted By must be 3 characters or longer!")

		if len(data["message"]) < 10:
			errors.append("Message must be 10 characters or longer!")

		if len(errors) > 0:
			return False, errors
		else:
			return True, Quote.quoteManager.create(quoted_by=data["quoted_by"], message=data["message"], poster_id=id)

class Quote(models.Model):
	quoted_by = models.CharField(max_length=255)
	message = models.CharField(max_length=255)
	poster = models.ForeignKey(User, related_name="quotes")
	favorites = models.ManyToManyField(User, related_name="favorite_quotes")

	quoteManager = QuoteManager()