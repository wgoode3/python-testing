# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Quote

def index(req):
	return render(req, "quotes_app/index.html")

def register(req):
	user = User.userManager.register(req.POST)
	if user["logged_in"]:
		req.session["user"] = {
			"id": user["user"].id,
			"name": user["user"].name
		}
		return redirect('/quotes')
	else:
		for error in user["errors"]:
			messages.add_message(req, messages.ERROR, error)
		return redirect('/')

def login(req):
	user = User.userManager.login(req.POST)
	if user["logged_in"]:
		req.session["user"] = {
			"id": user["user"].id,
			"name": user["user"].name
		}
		return redirect('/quotes')
	else:
		for error in user["errors"]:
			messages.add_message(req, messages.ERROR, error)
		return redirect('/')

def logout(req):
	req.session.clear()
	return redirect('/')

def quotes(req):
	if 'user' not in req.session:
		messages.add_message(req, messages.ERROR, "You must log in first!")

	all_quotes = Quote.quoteManager.all()
	favorite_quotes = User.userManager.get(id=req.session["user"]["id"]).favorite_quotes.all()

	for quote in favorite_quotes:
		all_quotes = all_quotes.exclude(id=quote.id)

	return render(req, "quotes_app/quotes.html", {"quotes": all_quotes, "favorite_quotes": favorite_quotes})

def addQuote(req):
	quote = Quote.quoteManager.addQuote(req.POST, req.session["user"]["id"])
	if not quote[0]:
		for error in quote[1]:
			messages.add_message(req, messages.ERROR, error)
	else:
		quote[1].favorites.add(User.userManager.get(id=req.session["user"]["id"]))
	return redirect("/quotes")

def showUser(req, id):
	return render(req, "quotes_app/user.html", {"user": User.userManager.get(id=req.session["user"]["id"])})

def favorite(req, id):
	Quote.quoteManager.get(id=id).favorites.add(User.userManager.get(id=req.session["user"]["id"]))
	return redirect("/quotes")

def unfavorite(req, id):
	Quote.quoteManager.get(id=id).favorites.remove(User.userManager.get(id=req.session["user"]["id"]))
	return redirect("/quotes")