from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.core.urlresolvers import reverse
from django.contrib import messages
from .models import User

def register(request):

	check = User.userManager.register(request.POST['username'], request.POST['email'], request.POST['password'], request.POST['confirm_password'])

	if check[0]:
		request.session['user_id'] = check[1].id
		request.session['username'] = check[1].username
		return redirect(reverse('message_home'))
	else:
		for error in check[1]:
			messages.add_message(request, messages.ERROR, error)
		return redirect(reverse('message_index'))

def login(request):
	
	check = User.userManager.login(request.POST['email'], request.POST['password'])

	if check[0]:
		request.session['user_id'] = check[1].id
		request.session['username'] = check[1].username
		return redirect(reverse('message_home'))
	else:
		for error in check[1]:
			messages.add_message(request, messages.ERROR, error)
		return redirect(reverse('message_index'))

def logout(request):
	request.session.clear()
	messages.add_message(request, messages.SUCCESS, 'Log out successful!')
	return redirect(reverse('message_index'))