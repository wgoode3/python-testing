from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index, name='message_index'),
    url(r'^messages$', views.home, name='message_home'),
    url(r'^messages/send$', views.home, name='message_send'),
    url(r'^messages/(?P<user_id>\d+)$', views.conversation),
    url(r'^messages/sent$', views.sent),
    url(r'^messages/received$', views.received),
]