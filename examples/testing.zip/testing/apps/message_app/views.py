from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from models import User, Message

def index(request):
	return render(request, 'message_app/index.html')

def home(request):
	if 'user_id' not in request.session:
		return redirect('/')
	if request.method == 'GET':
		context = {
			'sent': Message.messageManager.filter(user_from = request.session['user_id']).order_by('-id')[:3],
			'received': Message.messageManager.filter(user_to = request.session['user_id']).order_by('-id')[:3]
		}
		users = User.userManager.all().exclude(id=request.session['user_id'])
		for msg in context['sent']:
			users = users.exclude(id=msg.user_to_id)
		for msg in context['received']:
			users = users.exclude(id=msg.user_from_id)
		context['users'] = users
		return render(request, "message_app/home.html", context)
	elif request.method == 'POST':
		Message.messageManager.send(request.POST['message'], request.session['user_id'], request.POST['user_to'])
		return redirect(reverse('message_home'))

def conversation(request, user_id):
	if 'user_id' not in request.session:
		return redirect('/')
	if request.method == 'GET':
		sent = Message.messageManager.filter(user_from = request.session['user_id']).filter(user_to=user_id)
		received = Message.messageManager.filter(user_to = request.session['user_id']).filter(user_from=user_id)
		conversation = [msg for msg in sent] + [msg for msg in received]
		conversation.sort(key=lambda x: x.created_at)
		context = {
			'user_id': user_id,
			'conversation': conversation
		}
		return render(request, 'message_app/chat.html', context)
	elif request.method == 'POST':
		Message.messageManager.send(request.POST['message'], request.session['user_id'], user_id)
		return redirect('/messages/{}'.format(user_id))

def sent(request):
	if 'user_id' not in request.session:
		return redirect('/')
	sent = Message.messageManager.filter(user_from = request.session['user_id'])
	return render(request, "message_app/sent.html", {'sent': sent})

def received(request):
	if 'user_id' not in request.session:
		return redirect('/')
	received = Message.messageManager.filter(user_to = request.session['user_id'])
	return render(request, "message_app/received.html", {'received': received})

